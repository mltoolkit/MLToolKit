# -*- coding: utf-8 -*-
"""
Created on Sun July 01 2019
@Last update: Sun July 14 2019
@author: Sumudu Tennakoon
@licence:
   Copyright 2019 Sumudu Tennakoon

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
@notice: 
    If you use part of this code, concepts or code pattern, please 
    kindly give credits when necessary.    
   
"""

import pandas as pd
import numpy as np
import mltk as mltk
import traceback
import csv
import os

def PostProcess(DataFrame, score_result_columns, file_reference, dropbox_folder, temp_folder): # !! DO NOT CHANGE THE FUNCTION DEFINITION !!
	
    # ACTION 1 : SAVE SCORED DATA INTO FILE
	
	fieldsToSave = ['ID']
	mltk.save_output_file(DataFrame[fieldsToSave], file_path='{}.csv'.format(os.path.join(upload_folder, file_reference)))
	
    # ACTION 2 : PUSH SCORED DATA INTO DB SERVER	
	
	# SUMMARIZE THE SCORE RESULTS AND/OR GIVE MESSAGE TO API CALLER WITH THE ACTION DESTAILS.
	OutoutDataFrame = DataFrame #Default output 
	
	return OutoutDataFrame # !! DO NOT CHANGE THE FUNCTION RETURN STATEMENT !!