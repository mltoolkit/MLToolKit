# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 2019
@Last update: Sun July 01 2019
@author: Sumudu Tennakoon
@licence:
   Copyright 2019 Sumudu Tennakoon

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
@notice: 
    If you use part of this code, concepts or code pattern, please 
    kindly give credits when necessary.    
   
"""
import json
import numpy as np
import requests

url = "http://127.0.0.1:5000/ml_api_json"
model_input_data = {'ID':'A002',
      'age': 32,
      'workclass': 'Private',
      'education': 'Doctorate',
      'education-num': 16,
      'marital-status': 'Married-civ-spouse',
      'occupation': 'Prof-specialty',
      'relationship': 'Husband',
      'race': 'Asian-Pac-Islander',
      'sex': 'Male',
      'capital-gain': 0,
      'capital-loss': 0,
      'hours-per-week': 40,
      'native-country': '?'}

input_json_str = json.dumps(model_input_data)

params = {
    'InputData': input_json_str
    } 

Response = requests.get(url, params=params)
print('Response Status: ', Response.status_code)
print('Output:', json.loads(Response.text))   