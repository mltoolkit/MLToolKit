# -*- coding: utf-8 -*-
"""
Created on Sun July 01 2019
@Last update: Sun July 14 2019
@author: Sumudu Tennakoon
@licence:
   Copyright 2019 Sumudu Tennakoon

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
@notice: 
    If you use part of this code, concepts or code pattern, please 
    kindly give credits when necessary.    
   
"""

import pandas as pd
import numpy as np
import mltk as mltk
import traceback
import csv
import os

def ETL(DataFrame):
    # Add ID column
    DataFrame = mltk.add_identity_column(DataFrame, id_label='ID', start=1, increment=1)
    
    # Clean column names
    DataFrame = mltk.clean_column_names(DataFrame, replace='')
    input_columns = list(DataFrame.columns)

    variables_setup_dict = """   
    {
        "setting":"model",

        "variables": {            
                "category_variables" : ["sex", "nativecountry", "race", "occupation", "workclass", "maritalstatus", "relationship"],
                "binary_variables": [],
                "target_variable":"HighIncome"
        },


        "transforms": {
            "type":"transforms",
            "variable_class": "num",
            "include":false,
            "show_output":false,
            "rule_set": [
                {
                    "variable":"age", 
                    "to": "normalizedage", 
                    "operation":"normalize", 
                    "parameters":{"method":"zscore"}
                },
                {
                    "variable":"hoursperweek", 
                    "to": "normalizedhoursperweek", 
                    "operation":"normalize", 
                    "parameters":{"method":"minmaxfs"}
                }
            ]
        },

        "conditions":{
            "type":"conditions",
            "variable_class": "bin",
            "include":true,
            "show_output":false,
            "rule_set":[        
                {
                    "bin_variable":"CapitalGainPositive", 
                    "str_condition":"capitalgain>0"
                },

                {
                    "bin_variable":"CapitalLossPositive", 
                    "str_condition":"capitalloss>0"
                }
            ]
        },

        "buckets":{
            "type":"buckets",
            "variable_class": "cat",
            "include":true,
            "show_output":false,
            "rule_set":[
                {
                    "variable":"age", 
                    "category_variable":null, 
                    "str_labels":["0", "20", "30", "40", "50", "60", "INF"],
                    "right_inclusive":true
                },
                {
                    "variable":"educationnum", 
                    "category_variable":null, 
                    "str_labels":["1", "4", "6", "8", "10", "13", "16"],
                    "right_inclusive":true
                },
                {
                    "variable":"hoursperweek", 
                    "category_variable":null, 
                    "str_labels":["0", "20", "40", "50", "60", "80", "INF"],
                    "right_inclusive":true
                }
            ]
        },

        "category_merges":{
            "type":"category_merges",
            "variable_class": "cat",
            "include":true,
            "show_output":false,
            "rule_set":[
                {
                    "variable":"maritalstatus", 
                    "category_variable":"maritalstatus", 
                    "group_value":"Married", 
                    "values":["Married-civ-spouse", "Married-spouse-absent", "Married-AF-spouse"]
                }
            ]
        },

        "pair_equality": {
            "type":"pair_equality",
            "variable_class": "cat",
            "include":false,
            "show_output":false,
            "rule_set":[
                {
                    "variable1":"age", 
                    "variable2":"hoursperweek",
                    "category_variable":"TestGroup"
                }
            ]
        }
    }
    """    
    
    DataFrame, categoryVariables, binaryVariables, targetVariable = mltk.setup_variables_task(DataFrame, variables_setup_dict)
    
    # Create One Hot Encoded Variables
    DataFrame, featureVariables, targetVariable = mltk.to_one_hot_encode(DataFrame, category_variables=categoryVariables, binary_variables=binaryVariables, target_variable=targetVariable)

    return DataFrame, input_columns